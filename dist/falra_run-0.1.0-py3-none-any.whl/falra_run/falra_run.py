def hi():
    print('hi falra_run')


if __name__ == "__main__":
    hi()
